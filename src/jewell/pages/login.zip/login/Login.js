import React from 'react';
import StatusBar from '../../components/layouts/StatusBar';


class Login extends React.Component {

    constructor(props) {
        super(props);
        console.log(props);
    }

    render() {
        return (
            <div className='col-sm login-form-card mt-5'>

                <div className="card login-card">
                    <div className="login-card-header">
                        Sigin into your account
                    </div>
                    <StatusBar status={this.props.status} onStatusClose={this.props.onStatusClose} />


                    <div className="card-body">
                        <form>
                            <div className="form-group mt-4">
                                <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                {/* <small id="emailHelp" className="form-text text-muted">We'll never share your email with anyone else.</small> */}
                            </div>
                            <div className="form-group mt-4">
                                <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" />
                            </div>

                            {/* <div className="form-check mt-4">
                            <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                            <label className="form-check-label" for="exampleCheck1">Check me out</label>
                        </div> */}
                            <button type="submit"
                                className="form-control btn btn-light float-end brown jewell-bg-color fs-20 font-weight-bold mt-4 mb-4">Login
                            </button>
                            <hr className='login-hr'></hr>
                            <button type="submit" className="form-control btn btn-light mt-1 float-end brown jewell-bg-color">
                                <i className='fa-solid fab fa-google red'></i>&nbsp;&nbsp;Login with Google
                            </button>
                            <button type="submit" className="form-control btn btn-light mt-4 mb-4 float-end brown jewell-bg-color">
                                <i className='fa-solid fab fa-facebook fb-blue'></i>&nbsp;&nbsp;Login with Facebook
                            </button>
                            <hr className='login-hr'></hr>
                            <div className='d-flex justify-content-between fs-14 brown'>
                                <a href='/forget/password' className="brown">
                                    Forget Password
                                </a>
                                <a href='/' className="brown">
                                    Have a problem in login ?
                                </a>
                            </div>
                            <hr className='login-hr'></hr>
                            <a type="submit" href="register"
                                className="form-control btn btn-light float-end brown jewell-bg-color fs-20 font-weight-bold mt-4 mb-4">Signup
                            </a>
                        </form>

                    </div>
                </div >
            </div>
        )
    }

}


export default Login;




