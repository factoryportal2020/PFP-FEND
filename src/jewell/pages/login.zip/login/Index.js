import React from 'react';
import Login from './Login';
import ForgetPassword from './ForgetPassword';
import ResetPassword from './ResetPassword';
import Register from './Register';
import StatusBar from '../../components/layouts/StatusBar';
import { connect } from 'react-redux';

class Index extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            pathname: "login",
            comp: "",
            status: { show: false, type: 'success', msg: '' },
        }
    }

    componentWillReceiveProps(nextProps) {
        // console.log(nextProps)
        // console.log(this.props)
        // console.log(this.state)
        this.settingPathname();
    }

    componentDidMount() {
        this.settingPathname()
    }


    settingPathname() {
        let pathname = (window.location.pathname.split('/')[1]) ? window.location.pathname.split('/')[1] : "login";
        // console.log(this.state);
        let comp = <Login pathname={pathname} status={this.state.status} onStatusClose={this.onStatusClose} />;

        if (pathname == "forget") {
            comp = <ForgetPassword pathname={pathname} status={this.state.status} onStatusClose={this.onStatusClose} />
        } else if (pathname == "reset") {
            comp = <ResetPassword pathname={pathname} status={this.state.status} onStatusClose={this.onStatusClose} />
        } else if (pathname == "register") {
            comp = <Register pathname={pathname} status={this.state.status} onStatusClose={this.onStatusClose} />
        }
        this.setState({ pathname: pathname, comp: comp });
    }


    async emptyStatusMsg(submitted = false) {
        let stateObj = { ...this.state };
        stateObj.status = { show: false, type: 'success', msg: '' }
        stateObj.pathname = "login"
        this.setState({ ...stateObj }, () => {
        });
    }

    onStatusClose() {
        this.emptyStatusMsg(true);
    }

    render() {
        return (
            <div className='row login-row'>
                <div className='col-sm login-half-round vertical right'>
                    <div className='login-half-round-content'>
                        <a href="/">
                            Pocket<br />Poche<br />Admin
                        </a>
                        <h5 className='grey'>Task Management Portal</h5>
                    </div>
                </div>
                {this.state.comp}
            </div>
        )
    }
}

export default Index;
