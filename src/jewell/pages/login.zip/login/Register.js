import React from 'react';
import registerService from '../../services/register.service';
import { formEntities, formStates } from './Entity/Register';
import Form from '../../components/forms/Form';

import StatusBar from '../../components/layouts/StatusBar';
import Preloader from '../../components/layouts/Preloader';
import { connect } from 'react-redux';
import { Navigate } from 'react-router-dom';
import LoginIndex from './Index';


// auth
import { registerUser } from '../../features/auth/authAuctions';

class Register extends React.Component {
    constructor(props) {
        super(props);
        console.log(props)
        this.child = React.createRef();
        this.state = {
            // form
            states: formStates,
            status: props.status,
            entities: formEntities,
            action: "Edit",
            pathname: props.pathname,
            //Auth
            auth: { ...props.auth }
        }
    }

    componentWillReceiveProps(nextProps) {
        let auth = nextProps.auth;

        if ((!auth.success) && (auth.errorsModalTrigger == "d-block")) {
            console.log("lll");
            this.child.current.showServerErrorMsg(auth.errors);
        }

        if (auth.success) {
            console.log("ssss");
            this.setStatusMsg("success", auth.message)
        }
    }

    specialValidationforUpdate(fieldName, hasErr) {
        return hasErr;
    }

    async emptyStatusMsg(submitted = false) {
        let stateObj = { ...this.state };
        // stateObj.status = { show: false, type: 'success', msg: '' }
        stateObj.states.submitted = submitted;
        stateObj.pathname = "login"
        this.setState({ ...stateObj }, () => {
        });
    }

    onStatusClose() {
        this.emptyStatusMsg(true);
    }

    async setStatusMsg(type, msg) {
        let stateObj = { ...this.state };
        stateObj.status = { show: true, type: type, msg: msg };
        stateObj.auth.preLoading = true;
        this.setState({ ...stateObj }, () => { });
        setInterval(() => {
            this.emptyStatusMsg(true);
        }, 3000);

    }

    async saveDataApiCall(params) {
        await this.props.registerUser(params)
    }

    render() {
        return (
            <div className='col-sm login-form-card mt-5'>
                {(this.state.states.submitted) ?
                    <Navigate to={'/'} element={<LoginIndex status={this.state.status}/>} /> : ""
                }
                <StatusBar status={this.state.status} onStatusClose={this.onStatusClose} />

                {this.state.auth.preLoading ? <Preloader /> : ""}
                <div className="card login-card">
                    <div className="login-card-header">
                        Register New Account
                    </div>

                    <div className="card-body">
                        <form>
                            <>
                                < Form
                                    entities={this.state.entities}
                                    states={this.state.states}
                                    action={this.state.action}
                                    saveDataApiCall={(params) => this.saveDataApiCall(params)}
                                    specialValidationforUpdate={(fieldName, hasErr) => this.specialValidationforUpdate(fieldName, hasErr)}
                                    ref={this.child}

                                // errorsModalTrigger={this.state.auth.errorsModalTrigger}
                                // errors={this.state.auth.errors}
                                />
                            </>



                            <hr className='login-hr'></hr>

                            <div className='d-flex justify-content-between fs-14 brown'>
                                <a href='/' className="brown">
                                    Login
                                </a>
                                <a href='/' className="brown">
                                    Have a problem in Register ?
                                </a>
                            </div>
                        </form>

                    </div>
                </div >
            </div>
        )
    }

}

const mapStateToProps = state => ({
    ...state
});

const mapDispatchToProps = dispatch => ({
    registerUser: (payload) => dispatch(registerUser(payload))
});



export default connect(mapStateToProps, mapDispatchToProps)(Register);




{/* <div className="form-group mt-4">
    <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
</div>
<div className="form-group mt-4">
    <input type="number" className="form-control" id="exampleInputPassword1" placeholder="Mobile no" />
</div>
<div className="form-group mt-4">
    <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" />
</div>
<div className="form-group mt-4">
    <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Confirm Password" />
</div> */}


{/* <div className="form-check mt-4">
    <input type="checkbox" className="form-check-input" id="exampleCheck1" />
    <label className="form-check-label" for="exampleCheck1">Check me out</label>
</div> */}




// async saveDataApiCall(params) {

//     // this.setState({ preLoading: true });

//     let result = this.props.registerUser(params)
//     console.log(result);
//     // let callApi = (params.encrypt_id != null) ?
//     //     registerService.update(params) :
//     //     registerService.create(params);

//     // callApi.then(response => {
//     //     let data = response.data;
//     //     console.log(data);
//     //     if (!data.status) { // errors
//     //         this.child.current.showServerErrorMsg(data.message);
//     //         // this.setState({ preLoading: false });
//     //     } else { // success
//     //         // this.setState({ action: "list" });
//     //         this.child.current.setStatusMsg("success", data.message)
//     //         setInterval(() => {
//     //             this.child.current.emptyStatusMsg(true);
//     //         }, 3000);
//     //     }
//     // }).catch(e => {
//     //     this.child.current.setStatusMsg("danger", "Something went wrong")
//     //     this.setState({ preLoading: false });

//     // });
// }